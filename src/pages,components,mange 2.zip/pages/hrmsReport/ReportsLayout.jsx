import React from 'react';
import { NavLink, Outlet, Link } from 'react-router-dom';
import { Users, CalendarClock, Calendar, DollarSign, ArrowLeft } from 'lucide-react';

const reportCategories = [
    { name: 'Employee', href: '/reports/employee', icon: Users },
    { name: 'Attendance', href: '/reports/attendance', icon: CalendarClock },
    { name: 'Leave', href: '/reports/leave', icon: Calendar },
    { name: 'Payroll', href: '/reports/payroll', icon: DollarSign },
];

const ReportsLayout = () => {
    return (
        <div className="flex h-screen bg-background text-foreground">
            {/* Reports Sidebar */}
            <div className="w-full md:w-64 bg-card border-r border-border flex-shrink-0 flex flex-col">
                <div className="p-4 border-b border-border">
                    <div className="flex items-center gap-2 mb-2">
                        <Link to="/hrdashboard" className="p-1 hover:bg-background-muted rounded-full transition-colors" title="Back to Dashboard">
                            <ArrowLeft size={20} className="text-foreground-muted" />
                        </Link>
                        <h2 className="text-lg font-bold text-foreground">Reports</h2>
                    </div>
                    <p className="text-sm text-foreground-muted ml-1">Select a category</p>
                </div>
                <nav className="p-2 space-y-1 flex-1 overflow-y-auto">
                    {reportCategories.map((category) => (
                        <NavLink
                            key={category.name}
                            to={category.href}
                            className={({ isActive }) =>
                                `flex items-center gap-3 px-3 py-2 rounded-lg text-sm font-medium transition-colors ${isActive
                                    ? 'bg-primary/10 text-primary'
                                    : 'text-foreground-muted hover:bg-background-muted hover:text-foreground'
                                }`
                            }
                        >
                            <category.icon size={18} />
                            {category.name}
                        </NavLink>
                    ))}
                </nav>
            </div>

            {/* Main Content Area */}
            <div className="flex-1 overflow-auto bg-background-muted">
                <Outlet />
            </div>
        </div>
    );
};

export default ReportsLayout;

import React from 'react';
import { NavLink, Outlet, Navigate, useLocation } from 'react-router-dom';

const tabs = [
    { name: 'Daily Attendance', href: 'daily' },
    { name: 'Monthly Summary', href: 'monthly' },
    { name: 'Overtime', href: 'overtime' },
    { name: 'Compliance', href: 'compliance' },
];

const AttendanceReports = () => {
    const location = useLocation();

    // Redirect to 'daily' if strictly at '/reports/attendance' or '/reports/attendance/'
    if (location.pathname === '/reports/attendance' || location.pathname === '/reports/attendance/') {
        return <Navigate to="daily" replace />;
    }

    return (
        <div className="flex flex-col h-full">
            {/* Top Navigation / Tabs */}
            <div className="bg-card border-b border-border px-6 sticky top-0 z-10">
                <div className="flex space-x-6 overflow-x-auto">
                    {tabs.map((tab) => (
                        <NavLink
                            key={tab.name}
                            to={tab.href}
                            className={({ isActive }) =>
                                `py-4 text-sm font-medium border-b-2 whitespace-nowrap transition-colors ${isActive
                                    ? 'border-primary text-primary'
                                    : 'border-transparent text-foreground-muted hover:text-foreground hover:border-gray-300'
                                }`
                            }
                        >
                            {tab.name}
                        </NavLink>
                    ))}
                </div>
            </div>

            {/* Report Content */}
            <div className="flex-1 p-6">
                <Outlet />
            </div>
        </div>
    );
};

export default AttendanceReports;

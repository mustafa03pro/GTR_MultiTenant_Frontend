
import React from 'react';
import { NavLink, Outlet, Navigate, useLocation } from 'react-router-dom';

const tabs = [
    { name: 'Master Employee Reports', href: 'master' },
    { name: 'Headcount', href: 'count' },
    { name: 'Demographics', href: 'demographics' },
    { name: 'Employment Status', href: 'employment-status' },
    { name: 'Employee Documents', href: 'documents' },
];

const EmployeeReports = () => {
    const location = useLocation();

    // Redirect to 'master' if strictly at '/reports/employee' or '/reports/employee/'
    if (location.pathname === '/reports/employee' || location.pathname === '/reports/employee/') {
        return <Navigate to="master" replace />;
    }

    return (
        <div className="flex flex-col h-full">
            {/* Top Navigation / Tabs */}
            <div className="bg-card border-b border-border px-6 sticky top-0 z-10">
                <div className="flex space-x-6 overflow-x-auto">
                    {tabs.map((tab) => (
                        <NavLink
                            key={tab.name}
                            to={tab.href}
                            className={({ isActive }) =>
                                `py-4 text-sm font-medium border-b-2 whitespace-nowrap transition-colors ${isActive
                                    ? 'border-primary text-primary'
                                    : 'border-transparent text-foreground-muted hover:text-foreground hover:border-gray-300'
                                }`
                            }
                        >
                            {tab.name}
                        </NavLink>
                    ))}
                </div>
            </div>

            {/* Report Content */}
            <div className="flex-1 p-6">
                <Outlet />
            </div>
        </div>
    );
};

export default EmployeeReports;

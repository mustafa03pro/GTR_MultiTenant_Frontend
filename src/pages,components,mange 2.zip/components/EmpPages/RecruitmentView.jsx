import React from 'react';

const RecruitmentView = () => {
    return (
        <div>
            
        </div>
    );
}

export default RecruitmentView;

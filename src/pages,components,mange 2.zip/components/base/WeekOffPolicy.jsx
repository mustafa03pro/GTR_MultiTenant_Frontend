import React, { useState, useEffect } from 'react';
import DashboardLayout from '../DashboardLayout';
import { Plus, Edit, Trash2, Loader, AlertCircle, X, RefreshCw } from 'lucide-react';
import axios from 'axios';
import SyncPolicyModal from '../attendance/SyncPolicyModal';

const DAYS_OF_WEEK = ['SUNDAY', 'MONDAY', 'TUESDAY', 'WEDNESDAY', 'THURSDAY', 'FRIDAY', 'SATURDAY'];

// Modal for adding/editing weekly off policies
const WeekOffPolicyModal = ({ isOpen, onClose, onSave, policy, loading }) => {
    const [formData, setFormData] = useState({
        name: '',
        code: '',
        offDays: [],
        rotate: false
    });
    const [modalError, setModalError] = useState('');

    useEffect(() => {
        if (policy) {
            setFormData({
                name: policy.name || '',
                code: policy.code || '',
                offDays: policy.offDays || [],
                rotate: policy.rotate || false
            });
        } else {
            setFormData({ name: '', code: '', offDays: [], rotate: false });
        }
        setModalError('');
    }, [policy, isOpen]);

    const handleChange = (e) => {
        const { name, value, type, checked } = e.target;
        if (type === 'checkbox' && name === 'rotate') {
            setFormData(prev => ({ ...prev, rotate: checked }));
        } else {
            setFormData(prev => ({ ...prev, [name]: value }));
        }
    };

    const handleDayChange = (day) => {
        setFormData(prev => {
            const newOffDays = prev.offDays.includes(day)
                ? prev.offDays.filter(d => d !== day)
                : [...prev.offDays, day];
            return { ...prev, offDays: newOffDays };
        });
    };

    const handleSubmit = (e) => {
        e.preventDefault();
        if (!formData.name.trim() || !formData.code.trim()) {
            setModalError('Name and Code are required.');
            return;
        }
        if (formData.offDays.length === 0) {
            setModalError('At least one off day must be selected.');
            return;
        }
        onSave(formData);
    };

    if (!isOpen) return null;

    return (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex justify-center items-center z-50 p-4">
            <div className="bg-white rounded-lg shadow-xl w-full max-w-lg">
                <div className="p-4 border-b flex justify-between items-center">
                    <h2 className="text-xl font-semibold">{policy ? 'Edit' : 'Add'} Weekly Off Policy</h2>
                    <button onClick={onClose} className="p-2 rounded-full hover:bg-slate-100">
                        <X className="h-5 w-5" />
                    </button>
                </div>
                <form onSubmit={handleSubmit}>
                    <div className="p-6 space-y-4">
                        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                            <div>
                                <label htmlFor="name" className="block text-sm font-medium text-slate-700">Name</label>
                                <input id="name" name="name" value={formData.name} onChange={handleChange} required className="input" />
                            </div>
                            <div>
                                <label htmlFor="code" className="block text-sm font-medium text-slate-700">Code</label>
                                <input id="code" name="code" value={formData.code} onChange={handleChange} required className="input" />
                            </div>
                        </div>
                        <div>
                            <label className="block text-sm font-medium text-slate-700">Off Days</label>
                            <div className="mt-2 grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 gap-2">
                                {DAYS_OF_WEEK.map(day => (
                                    <label key={day} className="inline-flex items-center">
                                        <input
                                            type="checkbox"
                                            checked={formData.offDays.includes(day)}
                                            onChange={() => handleDayChange(day)}
                                            className="h-4 w-4 rounded border-gray-300 text-blue-600 focus:ring-blue-500"
                                        />
                                        <span className="ml-2 text-sm text-slate-600 capitalize">{day.toLowerCase()}</span>
                                    </label>
                                ))}
                            </div>
                        </div>
                        <div>
                            <label className="inline-flex items-center">
                                <input
                                    type="checkbox"
                                    name="rotate"
                                    checked={formData.rotate}
                                    onChange={handleChange}
                                    className="h-4 w-4 rounded border-gray-300 text-blue-600 focus:ring-blue-500"
                                />
                                <span className="ml-2 text-sm text-slate-600">Rotate Weekly Off</span>
                            </label>
                        </div>
                        {modalError && <p className="text-red-500 text-sm">{modalError}</p>}
                    </div>
                    <div className="p-4 border-t bg-slate-50 flex justify-end gap-2">
                        <button type="button" onClick={onClose} className="btn-secondary" disabled={loading}>Cancel</button>
                        <button type="submit" className="btn-primary flex items-center" disabled={loading}>
                            {loading && <Loader className="animate-spin h-4 w-4 mr-2" />}
                            Save
                        </button>
                    </div>
                </form>
            </div>
        </div>
    );
};

const WeekOffPolicy = ({ embedded = false }) => {
    const [policies, setPolicies] = useState([]);
    const [loading, setLoading] = useState(true);
    const [modalLoading, setModalLoading] = useState(false);
    const [error, setError] = useState('');
    const [isModalOpen, setIsModalOpen] = useState(false);
    const [editingPolicy, setEditingPolicy] = useState(null);
    const [syncingPolicy, setSyncingPolicy] = useState(null);

    const API_URL = import.meta.env.VITE_API_BASE_URL;

    const fetchPolicies = async () => {
        setLoading(true);
        setError('');
        try {
            const token = localStorage.getItem('token');
            const response = await axios.get(`${API_URL}/weekly-off-policies`, {
                headers: { "Authorization": `Bearer ${token}` }
            });
            setPolicies(response.data);
        } catch (err) {
            setError('Failed to fetch weekly off policies. Please try again later.');
            console.error(err);
        } finally {
            setLoading(false);
        }
    };

    useEffect(() => {
        fetchPolicies();
    }, [API_URL]);

    const handleAdd = () => {
        setEditingPolicy(null);
        setIsModalOpen(true);
    };

    const handleEdit = (policy) => {
        setEditingPolicy(policy);
        setIsModalOpen(true);
    };

    const handleDelete = async (policyId, policyName) => {
        if (window.confirm(`Are you sure you want to delete the policy "${policyName}"?`)) {
            try {
                const token = localStorage.getItem('token');
                await axios.delete(`${API_URL}/weekly-off-policies/${policyId}`, {
                    headers: { "Authorization": `Bearer ${token}` }
                });
                setPolicies(policies.filter(p => p.id !== policyId));
            } catch (err) {
                setError('Failed to delete policy.');
                console.error(err);
            }
        }
    };

    const handleSave = async (policyData) => {
        setModalLoading(true);
        setError('');
        try {
            const token = localStorage.getItem('token');
            if (editingPolicy) {
                await axios.put(`${API_URL}/weekly-off-policies/${editingPolicy.id}`, policyData, {
                    headers: { "Authorization": `Bearer ${token}` }
                });
            } else {
                await axios.post(`${API_URL}/weekly-off-policies`, policyData, {
                    headers: { "Authorization": `Bearer ${token}` }
                });
            }
            setIsModalOpen(false);
            fetchPolicies();
        } catch (err) {
            setError(err.response?.data || 'Failed to save policy. The name or code might already exist.');
            console.error(err);
        } finally {
            setModalLoading(false);
        }
    };

    const handleOpenSyncModal = (policy) => {
        setSyncingPolicy(policy);
    };

    const handleConfirmSync = async (policy, selectedEmployeeCodes) => {
        if (selectedEmployeeCodes.length === 0) {
            alert("No employees selected.");
            return;
        }

        setError('');
        let successCount = 0;
        let errorCount = 0;

        try {
            const token = localStorage.getItem('token');
            const BASE_URL = import.meta.env.VITE_API_BASE_URL;

            for (const employeeCode of selectedEmployeeCodes) {
                try {
                    const payload = { weeklyOffPolicyId: policy.id };
                    await axios.put(`${BASE_URL}/time-attendence/${employeeCode}`, payload, { headers: { "Authorization": `Bearer ${token}` } });
                    successCount++;
                } catch (updateErr) {
                    console.error(`Failed to update weekly off policy for ${employeeCode}:`, updateErr);
                    errorCount++;
                }
            }

            alert(`Sync complete!\n- ${successCount} employees updated successfully.\n- ${errorCount} updates failed.`);

        } catch (err) {
            setError('An unexpected error occurred during the sync process.');
            console.error(err);
        }
    };

    const content = (
        <>
            <div className="p-6 md:p-8">
                <div className="flex justify-between items-center mb-6">
                    <h1 className="text-3xl font-bold text-slate-800">Weekly Off Policies</h1>
                    <button
                        onClick={handleAdd}
                        className="btn-primary flex items-center">
                        <Plus className="h-5 w-5 mr-2" />
                        Add Policy
                    </button>
                </div>

                {error && (
                    <div className="bg-red-100 border border-red-400 text-red-700 px-4 py-3 rounded relative mb-4" role="alert">
                        <strong className="font-bold">Error: </strong>
                        <span className="block sm:inline">{error}</span>
                    </div>
                )}

                <div className="bg-white rounded-xl shadow-sm overflow-hidden">
                    {loading ? (
                        <div className="flex justify-center items-center h-80"><Loader className="h-8 w-8 animate-spin text-blue-600" /></div>
                    ) : (
                        <div className="overflow-x-auto">
                            <table className="min-w-full bg-white">
                                <thead className="bg-slate-50">
                                    <tr>
                                        <th className="th-cell">Name</th>
                                        <th className="th-cell">Code</th>
                                        <th className="th-cell">Off Days</th>
                                        <th className="th-cell">Rotate</th>
                                        <th className="th-cell">Actions</th>
                                    </tr>
                                </thead>
                                <tbody className="text-slate-700">
                                    {policies.length > 0 ? (
                                        policies.map(p => (
                                            <tr key={p.id} className="border-b border-slate-200 hover:bg-slate-50">
                                                <td className="td-cell font-medium">{p.name}</td>
                                                <td className="td-cell text-sm text-slate-500">{p.code}</td>
                                                <td className="td-cell text-sm text-slate-500">{p.offDays.join(', ')}</td>
                                                <td className="td-cell text-sm text-slate-500">{p.rotate ? 'Yes' : 'No'}</td>
                                                <td className="td-cell">
                                                    <div className="flex items-center gap-2"> 
                                                        <button onClick={() => handleOpenSyncModal(p)} className="p-2 text-slate-500 hover:text-green-600 hover:bg-green-100 rounded-full" title="Sync to employees" disabled={!!syncingPolicy}>
                                                            {syncingPolicy?.id === p.id
                                                                ? <Loader className="h-4 w-4 animate-spin" />
                                                                : <RefreshCw className="h-4 w-4" />}
                                                        </button>
                                                        <button onClick={() => handleEdit(p)} className="p-2 text-slate-500 hover:text-blue-600 hover:bg-blue-100 rounded-full" title="Edit" disabled={!!syncingPolicy}>
                                                            <Edit className="h-4 w-4" />
                                                        </button>
                                                        <button onClick={() => handleDelete(p.id, p.name)} className="p-2 text-slate-500 hover:text-red-600 hover:bg-red-100 rounded-full" title="Delete" disabled={!!syncingPolicy}>
                                                            <Trash2 className="h-4 w-4" />
                                                        </button>
                                                    </div>
                                                </td>
                                            </tr>
                                        ))
                                    ) : (
                                        <tr>
                                            <td colSpan="5" className="text-center py-10 text-slate-500">
                                                <AlertCircle className="mx-auto h-12 w-12 text-slate-400" />
                                                <h3 className="mt-2 text-sm font-medium text-slate-900">No policies found</h3>
                                                <p className="mt-1 text-sm text-slate-500">Get started by creating a new weekly off policy.</p>
                                            </td>
                                        </tr>
                                    )}
                                </tbody>
                            </table>
                        </div>
                    )}
                </div>
            </div>
            <WeekOffPolicyModal
                isOpen={isModalOpen}
                onClose={() => setIsModalOpen(false)}
                onSave={handleSave}
                policy={editingPolicy}
                loading={modalLoading}
            />
            <SyncPolicyModal 
                isOpen={!!syncingPolicy} 
                onClose={() => setSyncingPolicy(null)} 
                policy={syncingPolicy}
                onSync={handleConfirmSync}
            />
        </>
    );

    if (embedded) {
        return content;
    }

    return (
        <DashboardLayout>{content}</DashboardLayout>
    );
}

export default WeekOffPolicy;
